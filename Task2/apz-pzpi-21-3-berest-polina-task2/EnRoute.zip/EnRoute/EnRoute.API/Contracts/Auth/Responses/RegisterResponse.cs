﻿namespace EnRoute.API.Contracts.Auth.Responses;

public record RegisterResponse(Guid UserId);